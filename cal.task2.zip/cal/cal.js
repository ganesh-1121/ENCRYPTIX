let isResultDisplayed = false;
let screen = document.getElementById("answer");
let buttons = document.querySelectorAll("button");
let screenValue = "";
let isOperator = false;

function isNumber(char) {
    return /^\d$/.test(char);
}

screen.readOnly = true;

buttons.forEach(button => {
    button.addEventListener("click", (e) => {
        handleButtonClick(e.target.innerText);
    });
});

function handleButtonClick(buttonText) {
    if (buttonText === "X") {
        if (!isOperator) {
            buttonText = "*";
            isOperator = true;
            screenValue += buttonText;
            screen.value = screenValue;
        }
    } else if (buttonText === "C") {
        clearScreen();
    } else if (buttonText === "=") {
        evaluateExpression();
    } else if (buttonText === "(" || buttonText === ")") {
        if (isResultDisplayed) {
            isResultDisplayed = false;
        }
        screenValue += buttonText;
        screen.value = screenValue;
    } else if (isNumber(buttonText) || buttonText === '.') {
        if (isResultDisplayed) {
            screenValue = buttonText;
            isResultDisplayed = false;
        } else {
            screenValue += buttonText;
        }
        screen.value = screenValue;
        isOperator = false;
    } else {
        if (!isOperator) {
            screenValue += buttonText;
            screen.value = screenValue;
            isOperator = true;
        }
    }
    screen.classList.remove("negative");
}

function clearScreen() {
    screenValue = "";
    screen.value = screenValue;
    screen.classList.remove("negative");
    isOperator = false;
    isResultDisplayed = false;
}

function evaluateExpression() {
    try {
        let result = eval(screenValue);
        screenValue = result.toString();
        screen.value = result;
        if (parseFloat(result) < 0) {
            screen.classList.add("negative");
        } else {
            screen.classList.remove("negative");
        }
        isResultDisplayed = true;
    } catch (error) {
        alert("PLEASE INPUT VALID EXPRESSION");
        clearScreen();
    }
}

document.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
        evaluateExpression();
    } else if (event.key === "Backspace" || event.key === "Delete") {
        deleteLastEntry();
    } else if (isNumber(event.key) || "()+-*/%.".includes(event.key)) {
        handleButtonClick(event.key);
    }
});

window.onerror = function () {
    alert("PLEASE INPUT VALID EXPRESSION");
    clearScreen();
};
