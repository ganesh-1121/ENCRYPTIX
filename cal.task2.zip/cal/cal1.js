const display = document.getElementById('answer');
const deleteButton = document.querySelector('button:nth-of-type(4)');
const historyButton = document.getElementById('historybutton');
const historyContainer = document.getElementById('history');
const bar1 = document.getElementById('bar1');
const bar2 = document.getElementById('bar2');

function clearAll() {
    display.value = '';
    screenValue = '';
}

function deleteLastEntry() {
    screenValue = screenValue.slice(0, -1);
    display.value = ""
    display.value = screenValue;
    
}

deleteButton.addEventListener("click", deleteLastEntry);
historyButton.addEventListener("click", showHistory);

function hideHistory() {
    historyContainer.style.display = 'none';
    bar1.style.display = 'none';
    bar2.style.display = 'none';
}

bar1.addEventListener('click', hideHistory);
bar2.addEventListener('click', hideHistory);

document.addEventListener('keydown', function (event) {
    handleKeyPress(event.key);
});

function handleKeyPress(key) {
    if (key === 'Enter') {
        handleButtonPress('=');
    } else if (key === 'Delete' || key === 'Backspace') {
        deleteLastEntry();
    } else if (/[0-9]/.test(key)) {
        handleButtonPress(key);
    } else if (/[\+\-\*\/%]/.test(key)) {
        handleButtonPress(key);
    }
}

function handleButtonPress(value) {
    const button = document.querySelector(`button[value="${value}"]`);
    if (button) {
        button.click();
    }
}

document.addEventListener('DOMContentLoaded', showHistory);
